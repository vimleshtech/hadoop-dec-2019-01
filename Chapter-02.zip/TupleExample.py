t = (11,2333,555,'fff',True)

print(t)
print(t[::-1])
print(t[::-2])
