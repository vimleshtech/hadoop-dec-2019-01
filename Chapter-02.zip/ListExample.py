
#
x = [11,33,45,656,33,55,33,5]

print('count of values :',len(x))
print('highest value :',max(x))
print('lowest value :',min(x))
print('total ',sum(x))

#print all data
print(x)

#print first value/by index
print(x[2]) #3rd value by count 

#iterate the list
for i in range(0,len(x)):
    print(x[i])

#or
for d in x:
    print(d)


#append
d = int(input('enter data :'))
x.append(d)

print(x)

#pop : remove from last
print(x.pop())
print(x)

#add new value at given position
d = int(input('enter data :'))
pos = int(input('enter position :'))
x.insert(pos,d)

print(x)

#remove
d = int(input('enter data which need to remove :'))
if d in x:
    x.remove(d)
print(x)

#sort
x.sort()
print(x)
print(x[::-1]) #in desc

print(x[::-2])










    













    
