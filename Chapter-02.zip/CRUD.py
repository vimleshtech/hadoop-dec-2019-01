#CRUD : Create Read Update and Delete

data  = []

while True:
    ch = input('press 1 for add 2 for show 3 for delete 4 for update 0 for exit')

    if ch =='1':
        d = int(input('enter data :'))
        data.append(d)
    elif ch=='2':
        print(data)
    elif ch=='3':
        x = int(input('enter data which need to remove '))
        if x in data:
            data.remove(x)
            print(x,' is removed')
        else:
            print(x, ' is not found ')
            
    elif ch =='4':
        x = int(input('enter existing data or value'))

        flag = 0
        for i in range(0,len(data)):
            if data[i] == x:
                nd =int(input('enter new value :'))
                data[i] = nd
                flag  =1

        if flag ==0:
            print('given value is not found')
        else:
            print('value is updated' )
    elif ch =='0':
        break
    else:
        print('Invalid choice , plz try again !!!')
        
            


                




                

                

        
        
