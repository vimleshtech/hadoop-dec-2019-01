d ={1:'one','d':'delta',10:[11,333,5,66,33]}

print(d)
print(d['d'])
print(d[1])


a= [11,33,55,5,'d']
#print(a['d']) #error
print(d['d'])


print(d.keys())
print(d.values())

#modify value
d['d'] =[11,33,55,566]
print(d['d'])

#add new key and value
d['x'] ='lambda'

print(d)

#how to iterate dict
for y in d.keys():
    print(d[y])



    


