#Nested loop

#Example - 1
for x in range(1,5):
    for y in range(1,4):
        print(y,end='') #print and don't change line 
    print() #new line 
        

#Example - 2    
for x in range(1,5):
    for y in range(1,x+1):
        print(y,end='') #print and don't change line
    print()



