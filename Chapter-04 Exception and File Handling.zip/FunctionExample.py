#No argument no return 
def wel():
    print('welcome to function world')

#No argument with return
def getNum():
    a= int(input('enter data :'))
    b = int(input('enter data :'))

    return a,b
#Argument with no return
def add(a,b):
    print(a+b)
#Argument with  return
def sub(a,b):
    c =a-b
    return c

#Argument with default value
def sum(a,b=0,c=0,d=0):
    m = a+b+c+d
    print(m)

#Argument with dynamic number of inputs
def mul(*a): #default input type is tuple
    print(type(a))
    print(a)
    o = 1
    for x in a:
        o*= x
    print(o)
    
#Recurssive function
def fact(x):
    if x==1:
        return 1
    else:
        return x*fact(x-1)

#Lambda
'''
def tax(x):
    x =x*.18
    return x
'''
tax = lambda x: (x*.18)+100

#tax = lambda x: if x>1000: x*.18 else: x*.12

#Comperssive list


l = lambda x: x*2



#call or invoke to function
wel()
wel()

x,y = getNum()
print(x+y)

x,y = getNum()
print(x*y)


add(11,3)
o = sub(11,3)
print(o)
add(o,10)

sum(1)
sum(1,34)
sum(1,4,55)
sum(1,54,566,4)

mul(11,33,445,5,3)
mul(11,33,445,5,3,44,343,33,5,56)

x= fact(5)
print(x)


o= tax(1200)
print(o)

d= [1,2,4] # [1,2,4,1,2,4]
o = l(d)
print(o)

#compressive list 
d = [a*2 for a in d]
print(d)








