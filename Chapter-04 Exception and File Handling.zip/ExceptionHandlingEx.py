'''
There are following inbuilt exception classes:

NameError
ValueError
IndexError
TypeError
ZeroDivisionError
FileNotFoundError
etc.


'''
a = int(input('enter data :'))
b = int(input('enter data :'))

try:
    if b<0:
        er = NameError('divisor cannot be less than 0')
        raise er 
    c = a/b
    print(c)

    o = a+b
    print(o)

except NameError as e:
    print(e)
except ZeroDivisionError as e:
    #print(e)
    pass
except:
    print('there is technical error')
finally:
    print('end of code ')






    






    
    

