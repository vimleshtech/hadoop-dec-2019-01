import CreateFile

#fname
#fname = input('enter file name :')
#read_data(fname)

#fname = input('enter file name :')
#mode = input('enter file mode  :')
#rcount  = int(input('enter rcount:'))
#save_data(fname,mode,rcount)

fname = input('enter file name :')
CreateFile.read_data(fname)

#
from CreateFile import *

fname = input('enter file name :')
read_data(fname)

#or
from CreateFile import read_data

fname = input('enter file name :')
read_data(fname)


#or
import CreateFile as c
fname = input('enter file name :')
c.read_data(fname)








