import os
os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training\Content')

def save_data(fname,mode,rcount):    
    f = open(fname,mode) #create new file
    for i in range(rcount):
        d = input('enter data :')
        
        f.write(d+'\n')
        #f.write('this is test file...\n')
        #f.write('this is test file...\n')
    f.close()
    print('data is saved')

def read_data(fname):
    fi = open(fname) #derault mode is r
    #print(fi.read()) #read all content from file
    #print(fi.readline()) #read one line at a time
    data = fi.readlines()
    print(type(data))
    print('rcount ',len(data))

    mc =0
    fc = 0
    for r in data:
        col = r.split(',')
        if col[2] =='male':
            mc+=1
        elif col[2] =='female':
            fc+=1
            
            
            
    print('female count ',fc)
    print('male count ',mc)
        
    fi.close()












    






         
