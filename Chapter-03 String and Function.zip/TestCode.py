fn = input('enter data:')
ln = input('enter data:')

name = fn+ln
print('name is ',name)

