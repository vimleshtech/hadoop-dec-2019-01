#re : regular expression 

s = input('enter data :')
print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())
print(s.strip())



print(len(s))
print(s.replace('a','xy')) #old char, new char

l = list(s)
print(l)


words = s.split() #default seperator is space 
print(words)
for w in words:
    print(w)


#count
print(s.count('i'))

#if s.endswith('de') == True:
if s.endswith('de'):  #return boolean 
    print('ending with de ')
else:
    print('not ending with de')
    


s = input('enter string ')
c = input('enter single char')

for w in s:
    if w.upper() == c.upper():
        if w.isupper():
            print(w.lower(),end='')
        elif w.islower():
            print(w.upper(),end='')

    else:
        print(w,end='')

        














